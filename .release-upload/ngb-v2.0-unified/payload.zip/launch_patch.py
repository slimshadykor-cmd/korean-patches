"""Offline entry point: uses only the bundled Windows runtime."""
from pathlib import Path
import os, sys, traceback, runpy
ROOT = Path(__file__).resolve().parent
os.environ['TCL_LIBRARY'] = str(ROOT/'runtime/python/tcl/tcl8.6')
os.environ['TK_LIBRARY'] = str(ROOT/'runtime/python/tcl/tk8.6')
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ.pop('PYTHONHOME', None)
os.environ.pop('PYTHONPATH', None)
log_dir = Path(os.environ.get('LOCALAPPDATA', str(ROOT)))/'NGBKoreanPatch'/'Logs'
log_dir.mkdir(parents=True, exist_ok=True)
log_file = log_dir/'startup.log'
with log_file.open('w', encoding='utf-8', buffering=1) as log:
    sys.stdout = sys.stderr = log
    print('NGB Public release v2.0 폭풍 portable launcher')
    print('Runtime:', sys.version)
    try:
        import tkinter as tk
        from tkinter import messagebox
        sys.path.insert(0, str(ROOT/'ngb_native11'))
        if '--check' in sys.argv:
            import patch_iso, rebuild_afs
            window = tk.Tk(); window.withdraw(); window.update(); window.destroy()
            print('PASS: bundled runtime, Tk window, patch imports')
        else:
            sys.argv = [str(ROOT/'ngb_native11/patch_gui.py')]
            runpy.run_path(sys.argv[0], run_name='__main__')
    except Exception:
        traceback.print_exc()
        try:
            import tkinter as tk
            from tkinter import messagebox
            window=tk.Tk();window.withdraw()
            messagebox.showerror('한글패치 실행 실패', '실행 중 오류가 발생했습니다.\n아래 로그를 확인해 주세요.\n\n'+str(log_file))
            window.destroy()
        except Exception:
            pass
        raise SystemExit(1)
