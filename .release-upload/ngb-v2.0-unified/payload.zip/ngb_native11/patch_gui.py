"""Public release patcher with optional Storm gameplay."""
from pathlib import Path
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

VERSION = '2.0'

def main():
    root = tk.Tk()
    root.title('닌자가이덴 블랙 한글패치 v' + VERSION + ' 폭풍')
    root.geometry('860x640')
    root.minsize(760, 520)
    root.columnconfigure(0, weight=1)
    root.rowconfigure(3, weight=1)
    root.option_add('*Font', ('맑은 고딕', 10))
    source = tk.StringVar()
    output = tk.StringVar()
    status = tk.StringVar(value='일반 ISO와 XISO를 자동 판별합니다. ISO를 선택하고 아래 버튼을 누르세요.')
    messages = queue.Queue()
    running = False
    controls = []

    header = tk.Frame(root)
    header.grid(row=0, column=0, sticky='ew', padx=20, pady=(18, 12))
    tk.Label(header, text='닌자가이덴 블랙 한글패치', font=('맑은 고딕', 18, 'bold')).pack()
    tk.Label(header, text='v2.0 폭풍 · 2026.10.25 선택 화면 메모리 개선 · ISO/XISO 자동 처리').pack(pady=(6, 0))

    def suggest_output():
        p = Path(source.get())
        target = p.with_name('NGB_Korean_v2.0.xiso.iso')
        n = 2
        while target.exists() or target.with_name(target.name + '.building').exists():
            target = p.with_name(f'NGB_Korean_v2.0_{n}.xiso.iso')
            n += 1
        output.set(str(target))

    paths = tk.Frame(root)
    paths.grid(row=1, column=0, sticky='ew', padx=20)
    paths.columnconfigure(1, weight=1)
    for row, (title, var, is_source) in enumerate([
        ('게임 ISO / XISO', source, True), ('새 ISO 저장 위치', output, False)
    ]):
        tk.Label(paths, text=title, anchor='w', width=17).grid(row=row, column=0, sticky='w', pady=8)
        entry = tk.Entry(paths, textvariable=var)
        entry.grid(row=row, column=1, sticky='ew', padx=(0, 10), ipady=5)
        controls.append(entry)
        def choose(v=var, s=is_source):
            path = (filedialog.askopenfilename(title='일반 Xbox ISO 또는 XISO 선택', filetypes=[('Xbox ISO', '*.iso')])
                    if s else filedialog.asksaveasfilename(title='새 ISO 저장 위치', defaultextension='.iso', initialfile='NGB_Korean_v2.0.xiso.iso'))
            if path:
                v.set(path)
                if s:
                    suggest_output()
        browse = tk.Button(paths, text='선택', command=choose, width=7, pady=4)
        browse.grid(row=row, column=2)
        controls.append(browse)

    state_frame = tk.Frame(root)
    state_frame.grid(row=2, column=0, sticky='ew', padx=20, pady=(10, 0))
    state_frame.columnconfigure(0, weight=1)
    tk.Label(state_frame, textvariable=status, anchor='w').grid(row=0, column=0, sticky='ew')
    progress = ttk.Progressbar(state_frame, mode='indeterminate')
    progress.grid(row=1, column=0, sticky='ew', pady=(8, 0))

    log_frame = tk.Frame(root)
    log_frame.grid(row=3, column=0, sticky='nsew', padx=20, pady=12)
    log_frame.columnconfigure(0, weight=1)
    log_frame.rowconfigure(0, weight=1)
    log = tk.Text(log_frame, wrap='word', height=10, state='disabled', font=('맑은 고딕', 10))
    log.grid(row=0, column=0, sticky='nsew')
    scroll = ttk.Scrollbar(log_frame, command=log.yview)
    scroll.grid(row=0, column=1, sticky='ns')
    log.configure(yscrollcommand=scroll.set)
    def append_log(text):
        log.configure(state='normal')
        log.insert('end', text)
        log.see('end')
        log.configure(state='disabled')
    append_log('지원 대상: Ninja Gaiden Black · Japan/Korea (En,Ja)\n형식 선택이나 별도 변환 없이 버튼 한 번으로 처리합니다.\nPython을 따로 설치할 필요가 없습니다.\n')

    def work(input_path, output_path):
        try:
            command = [sys.executable, str(Path(__file__).with_name('patch_iso.py')),
                       '--source', input_path, '--output', output_path]
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, encoding='utf-8', errors='replace',
                                       env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
            for line in process.stdout:
                messages.put(line)
            messages.put(('done', process.wait(), output_path))
        except Exception as exc:
            messages.put(str(exc) + '\n')
            messages.put(('done', 1, output_path))

    def start():
        nonlocal running
        if running:
            return
        if not source.get() or not output.get():
            messagebox.showerror('경로 선택', '원본 ISO와 새 ISO 저장 위치를 선택하세요.')
            return
        running = True
        button.configure(state='disabled', text='한글 XISO를 만드는 중입니다…')
        for control in controls:
            control.configure(state='disabled')
        status.set('패치 중입니다. 완료할 때까지 창을 닫지 마세요.')
        progress.start(15)
        threading.Thread(target=work, args=(source.get(), output.get()), daemon=True).start()

    # This footer keeps its requested height when the window is resized. The
    # log, not the primary action, receives the remaining expandable space.
    footer = tk.Frame(root)
    footer.grid(row=4, column=0, sticky='ew', padx=20, pady=(0, 18))
    footer.columnconfigure(0, weight=1)
    button = tk.Button(footer, text='새 한글 XISO 만들기', command=start,
                       font=('맑은 고딕', 16, 'bold'), height=2, pady=8,
                       bg='#2157A5', fg='white', activebackground='#174584',
                       activeforeground='white', disabledforeground='#D8E3F3',
                       relief='flat', cursor='hand2')
    button.grid(row=0, column=0, sticky='ew')

    def poll():
        nonlocal running
        while not messages.empty():
            item = messages.get()
            if isinstance(item, tuple):
                running = False
                progress.stop()
                button.configure(state='normal', text='새 한글 XISO 만들기')
                for control in controls:
                    control.configure(state='normal')
                if item[1] == 0:
                    status.set('완료했습니다. 새 XISO를 에뮬레이터에서 실행하세요.')
                    messagebox.showinfo('패치 완료', item[2] + '\n\nxemu를 완전히 종료한 뒤 이 ISO로 시작하세요.\n새 게임에서 블랙 또는 폭풍을 선택하세요. 폭풍은 새 저장 슬롯 사용을 권합니다.')
                else:
                    status.set('패치를 완료하지 못했습니다. 아래 기록을 확인하세요.')
                    messagebox.showerror('패치 실패', '아래 기록을 확인하세요. 원본 ISO는 변경되지 않았습니다.')
            else:
                append_log(item)
        root.after(100, poll)

    def close():
        if running:
            messagebox.showinfo('패치 중', '완료 후 창을 닫아 주세요.')
        else:
            root.destroy()
    root.protocol('WM_DELETE_WINDOW', close)
    root.after(100, poll)
    root.mainloop()

if __name__ == '__main__':
    main()
