"""Copy the Xbox game partition, append rebuilt files, and update root records.
Original ISO and all unchanged file data remain untouched. Not a gameplay test.
"""
from pathlib import Path
import argparse,hashlib,json,struct,shutil,base64,sys,os
from rebuild_afs import rebuild
from xbe_guard import validate_xbe
HERE=Path(__file__).resolve().parent;SECTOR=2048
def root_files(stream):
    stream.seek(0,2);length=stream.tell()
    for base in [0,405798912]:
        stream.seek(base+65536);d=stream.read(2048)
        if d[:20]==b'MICROSOFT*XBOX*MEDIA':break
    else:raise ValueError('Xbox 게임 파티션을 찾지 못했습니다. 압축을 푼 일반 Xbox ISO 또는 XISO를 선택하세요. 확장자만 바꾼 파일·분할 이미지·다른 기종 이미지는 지원하지 않습니다.')
    sector,size=struct.unpack_from('<II',d,20);at=base+sector*SECTOR
    if size>16*1024*1024 or at+size>length:raise ValueError('폴더 범위 오류')
    stream.seek(at);tree=stream.read(size);todo=[0];visited=set();files={}
    while todo:
        pos=todo.pop()
        if pos in visited or pos+14>size:raise ValueError('폴더 트리 오류')
        visited.add(pos);left,right,sector,sz,flags,n=struct.unpack_from('<HHIIBB',tree,pos)
        if not n or pos+14+n>size:raise ValueError('파일 이름 오류')
        name=tree[pos+14:pos+14+n].decode('ascii')
        if not flags&16:
            off=base+sector*SECTOR
            if off+sz>length:raise ValueError('파일 범위 오류')
            files[name]=(off,sz,at+pos+4)
        for branch in [left,right]:
            if branch:todo.append(branch*4)
    return base,files
def get(stream,item):
    stream.seek(item[0]);b=stream.read(item[1])
    if len(b)!=item[1]:raise ValueError('읽기 중단')
    return b
def sha(data): return hashlib.sha256(data).hexdigest()

def copy_game_partition(source, output, base):
    """Remove a Redump video prefix; retain all game-relative sector addresses."""
    created=False
    try:
        with source.open('rb') as original, output.open('xb') as result:
            created=True
            original.seek(base)
            shutil.copyfileobj(original, result, length=8*1024*1024)
            result.flush();os.fsync(result.fileno())
    except Exception:
        if created:output.unlink(missing_ok=True)
        raise

def current_entries(data, expected):
    if data[:4] != b'AFS\0' or len(data)<8: raise ValueError('AFS 헤더 오류')
    n=struct.unpack_from('<I',data,4)[0]
    if n!=len(expected) or 16+n*8>len(data): raise ValueError('AFS 구성원 수 오류')
    table,size=struct.unpack_from('<II',data,8+n*8)
    if size<n*48 or table+size>len(data): raise ValueError('AFS 이름 표 범위 오류')
    entries=[];ranges=[]
    for i,e in enumerate(expected):
        offset,length=struct.unpack_from('<II',data,8+i*8)
        name=data[table+i*48:table+i*48+32].split(b'\0')[0].decode('ascii')
        if name!=e['name'] or offset<16+n*8 or offset+length>table:
            raise ValueError('AFS 구성원 이름/범위 오류: '+e['name'])
        if length:ranges.append((offset,offset+length))
        entries.append({**e,'offset':offset,'size':length})
    ranges.sort()
    if any(a[1]>c[0] for a,c in zip(ranges,ranges[1:])): raise ValueError('AFS 구성원 범위 겹침')
    return entries

def version_member(data, a, forward):
    spec=a.get('version_member')
    if not spec:return data
    entries=current_entries(data,a['entries']);e=next(e for e in entries if e['name']==spec['name'])
    member=data[e['offset']:e['offset']+e['size']];h=sha(member)
    if h not in (spec['source_sha256'],spec['output_sha256']):
        if forward:raise ValueError('버전 표시 원본 검사 실패')
        return data
    wanted=spec['output_sha256'] if forward else spec['source_sha256']
    if h==wanted:return data
    buf=bytearray(member)
    for c in spec['changes']:
        before,after=(c['before'],c['after']) if forward else (c['after'],c['before'])
        if buf[c['offset']]!=before:raise ValueError('버전 표시 범위 검사 실패')
        buf[c['offset']]=after
    if sha(buf)!=wanted:raise ValueError('버전 표시 결과 검사 실패')
    result=bytearray(data);result[e['offset']:e['offset']+e['size']]=buf
    return bytes(result)

def archive_digest(data,a):
    return sha(version_member(data,a,False))

def rebuild_archive(old,a,package):
    old=version_member(old,a,False)
    if sha(old)==a['output_sha256']:return version_member(old,a,True)
    entries=current_entries(old,a['entries'])
    replacements={}
    for m in a['members']:
        data=(package/'assets/members'/a['path']/m['name']).read_bytes()
        if sha(data)!=m['output_sha256']:raise ValueError('패치 자료가 손상되었습니다: '+m['name'])
        replacements[m['name']]=data
    # Hash-checked, bounded deltas avoid bundling original character resources.
    by_name={e['name']:e for e in entries}
    for spec in a.get('member_patches',[]):
        name=spec['path']
        if name not in by_name or name in replacements:
            raise ValueError('중복되거나 없는 구성원 수정: '+name)
        e=by_name[name]
        member=old[e['offset']:e['offset']+e['size']]
        replacements[name]=bytes(patch_root(member,spec))
    new=rebuild(old,entries,replacements)
    if sha(new)!=a['output_sha256']:
        raise ValueError('지원하는 게임 데이터와 다릅니다: '+a['path']+' (수정하지 않은 원본 ISO로 다시 적용하세요.)')
    return version_member(new,a,True)

def patch_root(old, spec):
    digest = sha(old)
    if digest == spec['output_sha256']:
        return old
    if digest not in [spec['source_sha256'], *spec.get('accepted_previous_sha256', [])]:
        raise ValueError('지원하는 파일 크기 정보가 아닙니다: '+spec['path'])
    out = bytearray(old)
    for change in spec['changes']:
        at = change['offset']; data = base64.b64decode(change['data'])
        if at < 0 or at+len(data) > len(out):
            raise ValueError('파일 크기 정보 수정 범위 오류')
        out[at:at+len(data)] = data
    if len(out) != spec['output_length'] or sha(out) != spec['output_sha256']:
        raise ValueError('파일 크기 정보 재구성 검사 실패')
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True)
    p.add_argument('--package',default=str(HERE))
    args=p.parse_args()
    source=Path(args.source).resolve();output=Path(args.output).resolve();package=Path(args.package)
    temp=output.with_name(output.name+'.building')
    if not source.is_file():raise ValueError('원본 ISO 파일을 찾지 못했습니다. 파일을 다시 선택하세요.')
    if source==output or output.exists() or temp.exists():raise ValueError('새 출력 ISO 경로를 선택하세요.')
    if not output.parent.is_dir():raise ValueError('출력할 폴더가 없습니다.')
    plan=json.loads((package/'assets/build_plan.json').read_text(encoding='utf-8'))
    root_patches={a['path']:a for a in plan.get('root_patches',[])}
    targets=[*[a['path'] for a in plan['archives']],*root_patches,'default.xbe']
    with source.open('rb') as f:
        base,files=root_files(f)
        print('입력 형식: '+('일반 Xbox ISO — XISO로 자동 변환' if base else 'XISO — 형식 유지'),flush=True)
        print('Japan/Korea 게임 데이터 호환성을 확인하고 있습니다.',flush=True)
        for name in targets:
            if name not in files:raise ValueError('필요한 파일이 없습니다: '+name)
        oldxbe=get(f,files['default.xbe']);digest=sha(oldxbe)
        if digest==plan['xbe']['source_sha256']:changes=plan['xbe']['changes']
        elif digest==plan['xbe']['output_sha256']:changes=[]
        else:
            repair=next((r for r in plan.get('boot_repairs',[]) if r['previous_xbe_sha256']==digest),None)
            if repair is None:raise ValueError('ISO 형식은 읽었지만 내부 실행파일(default.xbe)이 지원 대상과 다릅니다. Japan/Korea (En,Ja)판을 선택하세요. USA/Europe판·별도 개조본은 지원하지 않습니다.\ndefault.xbe SHA-256: '+digest)
            changes=repair['changes']
        newxbe=bytearray(oldxbe)
        for change in changes:
            at=change['offset'];data=base64.b64decode(change['data']);newxbe[at:at+len(data)]=data
        if 'output_length' in plan['xbe']:del newxbe[plan['xbe']['output_length']:]
        if sha(newxbe)!=plan['xbe']['output_sha256']:raise ValueError('실행 파일 재구성 검사에 실패했습니다.')
        wanted_xbe=plan['xbe']['output_sha256']
        validate_xbe(newxbe)
        for name,spec in root_patches.items():patch_root(get(f,files[name]),spec)
    extra=sum(sum(e['size'] for e in a['entries']) for a in plan['archives'])+128*1024**2
    if shutil.disk_usage(output.parent).free<source.stat().st_size-base+extra:
        raise ValueError('새 ISO를 만들 디스크 공간이 부족합니다.')
    print('닌자가이덴 블랙 한글패치 v2.0 폭풍',flush=True)
    print('기존 ISO를 보존하고 새 ISO를 만드는 중입니다.',flush=True)
    created=False
    try:
        copy_game_partition(source,temp,base)
        created=True
        with source.open('rb') as original,temp.open('r+b') as result:
            for name in targets:
                old=get(original,files[name])
                if name=='default.xbe':new=newxbe
                elif name in root_patches:new=patch_root(old,root_patches[name])
                else:new=rebuild_archive(old,next(a for a in plan['archives'] if a['path']==name),package)
                if new==old:
                    print('최신 자료 확인: '+name,flush=True);continue
                result.seek(0,2);result.write(b'\0'*(-result.tell()%SECTOR));offset=result.tell()
                if offset//SECTOR>0xffffffff or len(new)>0xffffffff:raise ValueError('XISO 필드 범위 초과')
                result.write(new);result.seek(files[name][2]-base);result.write(struct.pack('<II',offset//SECTOR,len(new)))
                print('수정 자료 적용: '+name,flush=True)
            result.seek(0,2);result.write(b'\0'*(-result.tell()%SECTOR));result.flush()
            output_base,after=root_files(result)
            if output_base!=0:raise ValueError('xemu용 XISO 형식 변환 검사 실패')
            for name in targets:
                wanted=(wanted_xbe if name=='default.xbe' else root_patches[name]['output_sha256'] if name in root_patches else next(a['output_sha256'] for a in plan['archives'] if a['path']==name))
                if (sha(get(result,after[name])) if name=='default.xbe' or name in root_patches else archive_digest(get(result,after[name]),next(a for a in plan['archives'] if a['path']==name)))!=wanted:raise ValueError('완성 ISO 재읽기 오류: '+name)
        if output.exists():raise ValueError('작업 중 같은 이름의 출력 파일이 생겼습니다. 다른 저장 위치를 선택하세요.')
        temp.rename(output)
    except Exception:
        if created:temp.unlink(missing_ok=True)
        raise
    print('파일 적용·재읽기 검사 완료: '+str(output),flush=True)
    print('xemu를 종료한 뒤 이 새 ISO로 부팅하세요. 이전 스냅샷은 사용하지 마세요.',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('오류: '+str(exc),file=sys.stderr,flush=True)
        raise SystemExit(1)
