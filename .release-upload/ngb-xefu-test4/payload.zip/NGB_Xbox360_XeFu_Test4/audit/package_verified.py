"""Build the release only after a hash-matched, interactive New Game verification."""
from pathlib import Path
import argparse,base64,hashlib,json,shutil
R=Path(__file__).resolve().parent;O=R.parent/'fix_1104'
sha=lambda b:hashlib.sha256(b).hexdigest()
def delta(a,b):
 out=[];start=None
 for i,v in enumerate(b):
  changed=i>=len(a) or a[i]!=v
  if changed and start is None:start=i
  if not changed and start is not None:out.append({'offset':start,'data':base64.b64encode(b[start:i]).decode()});start=None
 if start is not None:out.append({'offset':start,'data':base64.b64encode(b[start:]).decode()})
 return out
p=argparse.ArgumentParser();p.add_argument('--target',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
b=a.target.read_bytes();v=json.loads(a.evidence.read_text())
assert v['candidate_sha256']==sha(b) and v['xefu_new_game_verified'] and v['first_stage_input_verified'],'No verified release target'
assert v['hardware_verified'] is False,'This builder documents PC XeFu validation only'
P=R/'package/NGB_Xbox360_XeFu_Test4';shutil.copytree(R/'package_pending/NGB_Xbox360_XeFu_Test4',P,dirs_exist_ok=True)
plan={'version':'XeFu Test4 (2026-11-04)','output_sha256':sha(b),'output_length':len(b),'sources':[],'validation':v}
for name,label in [('v2','정식 v2.0 (2026-10-26)'),('stream','Xbox 360 Stream Test1'),('test2','Xbox 360 Header Test2'),('native_candidate','Xbox 360 NativeLoad Test3')]:
 src=(O/(name+'.xbe')).read_bytes();plan['sources'].append({'label':label,'sha256':sha(src),'length':len(src),'changes':delta(src,b)})
(P/'patch_plan.json').write_text(json.dumps(plan,ensure_ascii=False),encoding='utf-8')
(P/'README_KO.txt').write_text('''닌자가이덴 블랙 한글패치 — Xbox 360 XeFu Test4
제작일: 2026-11-04

PC의 Xenia Edge + XeFu 환경에서 블랙 모드의 새 게임 시작, 첫 스테이지 진입과
게임 중 입력 반응을 확인한 수정본입니다. Xbox 360 실기 검증은 아직 하지 않았습니다.
동봉된 검증 기록에서 실제로 확인한 범위를 확인할 수 있습니다.

사용 방법
1. ZIP 전체를 새 폴더에 압축 해제합니다.
2. NGB_Xbox360_Test4.exe를 실행합니다. Python을 별도로 설치할 필요가 없습니다.
3. 기존 한글판의 default.xbe 또는 ISO/XISO를 선택합니다.
4. '새 시험판 파일 만들기'를 누릅니다.
5. XBE 입력: 생성된 default.xbe를 해당 한글판 게임 폴더에 복사합니다.
   ISO 입력: 새로 만들어진 NGB_Xbox360_XeFu_Test4.xiso.iso를 사용합니다.
기기에 복사하기 전 기존 default.xbe는 별도 보관해 주세요.

입력 지원: 2026-10-26 정식 v2.0 / Stream Test1 / Header Test2 / NativeLoad Test3.
원본 영문판·v1.0·다른 수정본은 지원하지 않습니다. 먼저 정식 v2.0을 적용해야 합니다.
이미 Test4가 적용된 파일은 재패치하지 않습니다.
입력 파일은 덮어쓰지 않으며 새 출력 폴더에 결과를 만듭니다.
세이브 파일은 수정하지 않습니다.

수정 내용
- 시작 시 동적으로 코드를 추가하는 Test3 방식 대신 정적 XBE 영역을 사용합니다.
- XeFu가 작업용 메모리와 문자열을 코드로 오해하지 않도록 영역을 구분합니다.
- 추가 코드의 반환 형식 분기 세 곳을 직접 점프로 정리합니다.
- 구형 Xbox CPU에서 지원하지 않는 MOVDQU 16곳을 같은 데이터를 처리하는
  MOVUPS와 NOP로 교체합니다.
- 한글 폰트와 번역 자료, 게임 메모리 할당 목표를 유지합니다.

검증 범위
동봉된 audit/verification.json에 시험 대상 해시와 도달 지점을 기록했습니다.
PC XeFu 검증은 Xbox 360 실기 동작을 보증하지 않습니다.
폭풍 모드의 실제 진행, 후반 챕터, 모든 복장·메뉴·세이브 조합과
Windows GUI 실행은 확인하지 않았습니다.

되돌리기: 별도 보관한 기존 한글판 default.xbe 또는 기존 ISO로 복원합니다.
''',encoding='utf-8-sig')
code=(P/'patch_tool.py').read_text();code=code.replace('로고 멈춤 대응을 위한 호환성 시험판 · 실기 구동 성공 미확인','PC XeFu에서 새 게임 진입 확인 · Xbox 360 실기 검증 전');(P/'patch_tool.py').write_text(code,encoding='utf-8')
A=P/'audit';A.mkdir(exist_ok=True);shutil.copy2(a.evidence,A/'verification.json')
for name in ['sse1_verification.json','stringsplit_metadata_validation.json','stringsplit_code_validation.json','package_verified.py']:
 shutil.copy2(R/name,A/name)
print(json.dumps({'package':str(P),'sha256':sha(b)},ensure_ascii=False))
