from pathlib import Path
import sys,json,hashlib,tempfile,struct,shutil
R=Path(__file__).resolve().parent;O=R.parent/'fix_1104';P=R/'package/NGB_Xbox360_XeFu_Test4'
sys.path.insert(0,str(P));import patch_tool as tool
sha=lambda b:hashlib.sha256(b).hexdigest()
candidate=(R/'stringsplit.xbe').read_bytes()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def iso(p,b,prefix):
 with p.open('wb') as f:
  f.seek(prefix+65536);f.write(b'MICROSOFT*XBOX*MEDIA'+struct.pack('<II',40,64))
  f.seek(prefix+40*2048);f.write(struct.pack('<HHIIBB',0,8,48,len(b),0,11)+b'default.xbe')
  f.seek(prefix+40*2048+32);f.write(struct.pack('<HHIIBB',0,0,42,64,16,4)+b'test')
  f.seek(prefix+42*2048);f.write(struct.pack('<HHIIBB',0,0,43,16,0,8)+b'keep.bin')
  f.seek(prefix+43*2048);f.write(b'0123456789ABCDEF')
  f.seek(prefix+48*2048);f.write(b)
cases=[]
with tempfile.TemporaryDirectory(dir=R) as temp:
 t=Path(temp)
 for name in ['v2','stream','test2','native_candidate']:
  b=(O/(name+'.xbe')).read_bytes()
  for form in ['xbe','xiso','rawiso','folder']:
   src=t/(name+'.'+form);dest=t/(name+'_'+form)
   if form=='folder':src.mkdir();(src/'default.xbe').write_bytes(b);real=src/'default.xbe'
   elif form=='xbe':src.write_bytes(b);real=src
   else:iso(src,b,0 if form=='xiso' else 405798912);real=src
   before=filehash(real);report=tool.generate(src,dest)
   if form in ['xbe','folder']:assert (dest/'default.xbe').read_bytes()==candidate
   else:
    generated=(dest/'NGB_Xbox360_XeFu_Test4.xiso.iso').read_bytes()
    sector,size=struct.unpack_from('<II',generated,65536+20)
    xbesec,xbelen=struct.unpack_from('<II',generated,sector*2048+4)
    assert generated[xbesec*2048:xbesec*2048+xbelen]==candidate
    assert generated[43*2048:43*2048+16]==b'0123456789ABCDEF'
    with src.open('rb') as f:f.seek(0 if form=='xiso' else 405798912);original=f.read()
    entry=sector*2048+4
    assert generated[:entry]==original[:entry] and generated[entry+8:len(original)]==original[entry+8:]
    assert len(generated)%65536==0
   assert filehash(real)==before and report['source_preserved'] and not report['xbox360_boot_verified'] and report['xefu_new_game_verified']
   assert (dest/'적용방법.txt').is_file()
   try:tool.generate(src,dest)
   except FileExistsError:pass
   else:raise AssertionError('existing destination overwritten')
   cases.append(name+'_'+form);print(cases[-1],'PASS',flush=True)
 for name,data in [('original',(O/'original.xbe').read_bytes()),('corrupt',candidate[:200]+b'BAD'+candidate[203:]),('already_test4',candidate),('truncated',candidate[:-100])]:
  src=t/(name+'.xbe');src.write_bytes(data);dest=t/(name+'_reject')
  try:tool.generate(src,dest)
  except ValueError:pass
  else:raise AssertionError(name)
  assert not dest.exists();cases.append(name+'_reject')
 plan=json.loads((P/'patch_plan.json').read_text());plan['sources'][0]['changes'][0]['data']='AAAA'
 bad=t/'badplan.json';bad.write_text(json.dumps(plan))
 try:tool.generate(O/'v2.xbe',t/'bad_output',bad)
 except ValueError:pass
 else:raise AssertionError('corrupt plan accepted')
 assert not (t/'bad_output').exists();cases.append('damaged_plan_reject')
report={'status':'PASS','cases':cases,'case_count':len(cases),'output_sha256':sha(candidate),'all_input_files_preserved':True,'other_iso_bytes_preserved_except_root_xbe_entry_and_appended_new_xbe':True,'real_full_game_iso_tested':False,'windows_gui_run':False,'xbox360_boot_tested':False,'xefu_new_game_verified':True}
(R/'package_validation.json').write_text(json.dumps(report,indent=2));print('ALL PASS',len(cases))
