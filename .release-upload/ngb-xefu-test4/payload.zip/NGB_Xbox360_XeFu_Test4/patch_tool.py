"""Generate one replacement XBE; input files are always read-only."""
from pathlib import Path
import base64,hashlib,json,os,sys,argparse,threading,queue
from xbe_io import read_source,validate
from iso_output import write_image
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()

def generate(source,output,plan_path=None):
 source=Path(source).resolve();output=Path(output).resolve()
 if source.is_dir():source=source/'default.xbe'
 data=read_source(source)
 plan=json.loads(Path(plan_path or ROOT/'patch_plan.json').read_text(encoding='utf-8'))
 if sha(data)==plan['output_sha256']:
  raise ValueError('이미 XeFu Test4이 적용된 실행파일입니다. 다시 패치할 필요가 없습니다.')
 matched=[s for s in plan['sources'] if s['sha256']==sha(data) and s['length']==len(data)]
 if not matched:
  raise ValueError('현재 지원하는 파일은 2026-10-26 정식 v2.0, Stream Test1, Header Test2 또는 NativeLoad Test3의 default.xbe입니다.\n해당 한글판 ISO/XISO 또는 default.xbe를 선택해 주세요.\n원본·v1.0·다른 수정본은 이 간편 도구에서 지원하지 않습니다.\n선택 파일 SHA-256: '+sha(data))
 validate(data)
 b=bytearray(data)
 for c in matched[0]['changes']:
  at=c['offset'];chunk=base64.b64decode(c['data'],validate=True)
  if at<0 or at>len(b):raise ValueError('패치 자료 범위 오류')
  b[at:at+len(chunk)]=chunk
 del b[plan['output_length']:]
 if len(b)!=plan['output_length'] or sha(b)!=plan['output_sha256']:raise ValueError('패치 자료 검증 실패')
 validate(b)
 output.mkdir(parents=True,exist_ok=False)
 with source.open('rb') as f:is_xbe=f.read(4)==b'XBEH'
 image_info=None
 if is_xbe:
  dst=output/'default.xbe'
  with dst.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 else:
  dst=output/'NGB_Xbox360_XeFu_Test4.xiso.iso'
  image_info=write_image(source,dst,b)
 if sha(read_source(dst))!=plan['output_sha256']:raise ValueError('출력 재읽기 검증 실패')
 report={'version':plan['version'],'source':str(source),'source_sha256':sha(data),'output_sha256':sha(b),'output_length':len(b),'source_preserved':True,'xbox360_boot_verified':False,'xefu_new_game_verified':bool(plan.get('validation',{}).get('xefu_new_game_verified',False))}
 report.update({'output_file':str(dst),'image_info':image_info})
 (output/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 (output/'적용방법.txt').write_text((ROOT/'README_KO.txt').read_text(encoding='utf-8-sig'),encoding='utf-8-sig')
 return report

def gui():
 import tkinter as tk
 from tkinter import filedialog,messagebox
 root=tk.Tk();root.title('닌자가이덴 블랙 · Xbox 360 Test4');root.geometry('850x660');root.minsize(820,640)
 root.option_add('*Font',('맑은 고딕',10))
 src=tk.StringVar();dst=tk.StringVar();status=tk.StringVar(value='정식 v2.0, Stream Test1, Header Test2 또는 NativeLoad Test3 파일을 선택해 주세요.')
 tk.Label(root,text='Xbox 360 Test4 · ISO / 실행파일 자동 처리',font=('맑은 고딕',19,'bold')).pack(pady=(22,12))
 tk.Label(root,text='PC XeFu에서 새 게임 진입 확인 · Xbox 360 실기 검증 전').pack()
 form=tk.Frame(root);form.pack(fill='x',padx=24,pady=18);form.columnconfigure(1,weight=1)
 def pick():
  p=filedialog.askopenfilename(title='정식 v2.0 / Stream Test1 / Header Test2 / NativeLoad Test3의 default.xbe 또는 ISO',filetypes=[('지원 게임 파일','*.xbe *.iso'),('모든 파일','*')])
  if p:
   src.set(p);o=Path(p).with_name('NGB360_Test4');n=2
   while o.exists():o=Path(p).with_name(f'NGB360_Test4_{n}');n+=1
   dst.set(str(o))
 tk.Label(form,text='기존 한글판 파일').grid(row=0,column=0,pady=8)
 tk.Entry(form,textvariable=src).grid(row=0,column=1,sticky='ew',padx=10,ipady=6)
 tk.Button(form,text='파일 선택',command=pick,width=10).grid(row=0,column=2)
 tk.Label(form,text='새 출력 폴더').grid(row=1,column=0,pady=8)
 tk.Entry(form,textvariable=dst).grid(row=1,column=1,columnspan=2,sticky='ew',padx=10,ipady=6)
 instructions='1. 위에서 정식 v2.0, Stream Test1, Header Test2 또는 NativeLoad Test3 파일을 선택합니다.\n2. 아래 버튼을 누르면 입력에 맞춰 새 파일이 만들어집니다.\n\nISO 선택 → 새 시험판 ISO 생성 → 평소 사용하던 방식으로 적용\nXBE 선택 → 새 default.xbe 생성 → 해당 한글판 폴더의 파일 하나 교체\n\n기기에서 이미 폴더로 실행한다면 XBE 하나만 전송하면 됩니다.\nISO를 선택한 경우에는 새 ISO가 만들어져 전체 이미지 전송이 필요할 수 있습니다.\n원본·v1.0은 지원하지 않습니다. 기존 실행파일과 세이브는 백업해 주세요.\n'
 tk.Label(root,text=instructions,justify='left',anchor='w').pack(fill='x',padx=28,pady=8)
 tk.Label(root,textvariable=status,anchor='w',wraplength=780).pack(fill='x',padx=28,pady=10)
 results=queue.Queue()
 def start():
  if not src.get() or not dst.get():messagebox.showerror('파일 선택','기존 한글판 파일을 선택해 주세요.');return
  chosen_src,chosen_dst=src.get(),dst.get();button.config(state='disabled')
  status.set('생성 중입니다. ISO는 크기와 디스크 속도에 따라 수 분 걸릴 수 있습니다.')
  def work():
   try:results.put((True,generate(chosen_src,chosen_dst)))
   except Exception as e:results.put((False,str(e)))
  def poll():
   try:ok,value=results.get_nowait()
   except queue.Empty:root.after(150,poll);return
   button.config(state='normal')
   if ok:
    status.set('완료: 새 파일 생성 및 실행파일 해시 확인')
    messagebox.showinfo('완료',value['output_file']+'\n\n출력 폴더의 적용방법.txt를 확인해 주세요.\n실제 기기 구동 성공은 아직 확인되지 않았습니다.')
    if sys.platform=='win32':
     try:os.startfile(chosen_dst)
     except OSError:pass
   else:status.set('생성 중단');messagebox.showerror('생성 중단',value)
  threading.Thread(target=work,daemon=True).start();root.after(150,poll)
 button=tk.Button(root,text='새 시험판 파일 만들기',command=start,font=('맑은 고딕',16,'bold'),height=2,bg='#2157A5',fg='white');button.pack(fill='x',padx=28,pady=8)
 root.mainloop()

if __name__=='__main__':
 if len(sys.argv)==1:gui()
 else:
  p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);a=p.parse_args();print(json.dumps(generate(a.source,a.output),ensure_ascii=False,indent=2))
